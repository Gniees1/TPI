
package src;

import java.time.LocalDate;
import src.entities.Categoria;
import src.entities.DataBase;
import src.entities.Menu;
import src.entities.Pedido;
import src.entities.Producto;
import src.entities.Usuario;
import src.enums.Estado;
import src.enums.FormaPago;
import src.enums.Rol;




public class Main {

  
    public static void main(String[] args) {
        
        Menu menu = new Menu();
        menu.mostrarMenu();
        
       
        
       
        
        
    }
    
}



