
package src.interfaces;


public interface Calculable {
    
    public void calcularTotal();
    
}
