
package src.entities;


import src.enums.Rol;
import java.util.List;
import java.util.ArrayList;

public class Usuario extends Base{
    
    //Atributos
    
    private String nombre;
    private String apellido;
    private String mail;
    private String celular;
    private String contrasenia;
    private Rol rol;
    private List<Pedido> pedidos;
    private static Long ultimoId = 0L;
    
    
    //Constructor
    public Usuario( String nombre, String apellido,String mail,String celular, String contrasenia, Rol rol){
        super();
        super.setId(++ultimoId);
        this.nombre= nombre;
        this.apellido = apellido;
        this.mail = mail;
        this.celular = celular;
        this.contrasenia = contrasenia;
        this.rol = rol;
        
        this.pedidos = new ArrayList<>();
    }
    
    //Getters

    public String getNombre() {
        return nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public String getMail() {
        return mail;
    }

    public String getCelular() {
        return celular;
    }

    public Rol getRol() {
        return rol;
    }

    public List<Pedido> getPedidos() {
        return pedidos;
    }
    
    
    
    
    
    
    //Setters

    public void setCelular(String celular) {
        this.celular = celular;
    }

    public void setMail(String mail) {
        this.mail = mail;
    }

    public void setRol(Rol rol) {
        this.rol = rol;
    }

    public void setContrasenia(String contrasenia) {
        this.contrasenia = contrasenia;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }
    
    
    
    
    
    
    //Metodos
    
    public void agregarPedido(Pedido p){
        if (p != null){
            pedidos.add(p);
        }else{
            System.out.println("El pedido no puede ser nulo");
        }
        
    }

    @Override
    public String toString() {
        String cadena = "USUARIO: "+ getNombre()+ " "+ getApellido()+ " | Mail: "+getMail()+ " | Rol: "+getRol();
        for (Pedido pedido: pedidos){
            cadena +=pedido;
        }
        return cadena;
    }

  
    
    
    
    
}
