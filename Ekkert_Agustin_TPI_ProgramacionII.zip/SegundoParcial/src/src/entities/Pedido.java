
package src.entities;

import src.enums.Estado;
import src.enums.FormaPago;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import src.interfaces.Calculable;


public class Pedido extends Base implements Calculable{
    
    //Atributos
    
    private LocalDate fecha;
    private Estado estado;
    private Double total;
    private FormaPago formapago;
    private List<DetallePedido> detalles;
    private Usuario usuario;
    private static Long ultimoId = 0L;
    
    
    //Constructor
    
    public Pedido( LocalDate fecha, Estado estado, Double total, FormaPago formapago, Usuario usuario){
        super();
        super.setId(++ultimoId);
        this.fecha = fecha;
        this.estado = estado;
        this.total= total;
        this.formapago = formapago;
        this.usuario = usuario;
        
        //instanciamos detalles
        this.detalles = new ArrayList<>();
        
        
    }
    
    
    //Getters

    public LocalDate getFecha() {
        return fecha;
    }

    public Estado getEstado() {
        return estado;
    }

    public Double getTotal() {
        return total;
    }

    public FormaPago getFormapago() {
        return formapago;
    }

    public List<DetallePedido> getDetalles() {
        return detalles;
    }

    public Usuario getUsuario() {
        return usuario;
    }
    
    
    //Setters

    public void setEstado(Estado estado) {
        this.estado = estado;
    }

    public void setFormapago(FormaPago formapago) {
        this.formapago = formapago;
    }
    
    
    
    
    
    
    //Metodos
    
    // sobreescribimos el calcularTotal de la interface calculable
    @Override
    public void calcularTotal(){
        //reiniciamos el valor de total para que no se acumule
        total = 0.0;
        for(DetallePedido detalle : detalles){
            total += detalle.calcularSubtotal();
        }
    }
    
    
    
    public void addDetallePedido(int cantidad, Producto p){
        
        DetallePedido detalle = new DetallePedido(cantidad ,p);
        
        detalles.add(detalle);
        
        //agregamos detalle a la lista y luego volvemos a calcular el total
        calcularTotal();
        
    }
    
    
    public DetallePedido finDetallePedidoByProducto(Producto p){
        
        int i = 0;
        DetallePedido detBuscado = null;
        
        while(i< detalles.size() && detBuscado == null){
            
          if(detalles.get(i).getProducto().getId().equals(p.getId())){
              detBuscado = detalles.get(i);
          }
          
          i++;
           
        }
        
        
        return detBuscado;
    }
    
    public void deleteDetallePedidobyProducto( Producto p){
        DetallePedido detAEliminar = finDetallePedidoByProducto(p);
        
        if (detAEliminar != null){
            detAEliminar.setEliminado(true);
            detalles.remove(detAEliminar);
            calcularTotal();
            System.out.println("Detalle eliminado con exito");
        }else{
            System.out.println("Detalle no encontrado");
        }
        
    }

    @Override
    public String toString() {
        
        
        /* Creamos una cadena donde se puedan concatenar los distintos elementos para visualizar bien los datos */
        String cadena = "\n===========================================================\n";
        cadena += " Pedido #"+getId() + " | Fecha=" + fecha + " | Estado: " + estado + " | FormaPago=" + formapago + "\n";
        cadena += "__________________________________________\n ";
        for (DetallePedido detalle: detalles){
            cadena += detalle + "\n";
        }
        
        cadena += "TOTAL DEL PEDIDO: $"+ total+ "\n";
        cadena += "_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ \n";
        
        return  cadena;
                
    }
    
    
    
    
}
