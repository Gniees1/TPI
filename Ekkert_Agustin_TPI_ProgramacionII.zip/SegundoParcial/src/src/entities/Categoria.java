
package src.entities;

import java.util.ArrayList;
import java.util.List;


public class Categoria extends Base {

    private String nombre;
    private String descripcion;
    private List <Producto> productos;
    
    //asignamos un contador para generar el id
    private static Long ultimoId = 0L;
    
    //Constructor
    public Categoria(String nombre, String descripcion){
        
        
        //pasamos a base el id asignado con el contador ultimoId
        super();
        this.nombre = nombre;
        this.descripcion = descripcion;
        super.setId(++ultimoId);
        this.productos = new ArrayList<>();
    }
    
    
    //Getters

    public String getNombre() {
        return nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public List<Producto> getProductos() {
        return productos;
    }

    
    //Setters 

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }
    
    
    
    
    //Metodos
    
    public void agregarProducto(Producto p){
        
        if(p != null){
          productos.add(p);
        } else{
            System.out.println("No se permiten productos null");
        }
        
    }
    
    public void listarCategorias(){
        
    }
    
    
    
    @Override
    public String toString() {
        return "Categoria #"+ this.getId() +" "+ this.nombre + ": "+ this.descripcion;
    }
    
    
    
}
