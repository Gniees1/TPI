
package src.entities;

import java.time.LocalDateTime;


public abstract class Base {
    
    
    //Atributos
    
    private Long id;
    private boolean eliminado;
    private LocalDateTime createdAt;
    
    
    
    
    
    
    
    
    
    //Constructor
    public Base(){
        this.eliminado = false;
        
        //localdatetime.now() asigna la fecha y hora actual del sistema
        this.createdAt = LocalDateTime.now();
        
    }
    
    
    //Getters

    public Long getId() {
        return id;
    }

    public boolean isEliminado() {
        return eliminado;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    //Setters

    protected void setEliminado(boolean eliminado) {
        this.eliminado = eliminado;
    }
    
    protected void setId(Long id){
        this.id = id;
    }
    
    
    @Override
    public abstract String toString();
        
    
    
    
    
      
    
}
