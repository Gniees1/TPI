
package src.entities;

import Excepciones.ValorInexistenteException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import src.enums.Estado;
import src.enums.FormaPago;
import src.enums.Rol;


public class DataBase {
    private static Scanner sc = new Scanner(System.in);
    
    protected static List<Categoria> categorias = new ArrayList<>();

    protected static List<Producto> productos = new ArrayList<>();

    protected static List<Usuario> usuarios = new ArrayList<>();

    protected static List<Pedido> pedidos = new ArrayList<>();
    
    
    
    
    
    //METODOS PARA CATEGORIA
    
    
    
    
    
    public static void crearCategoria(){
        System.out.println("Ingrese el nombre que desea para la nueva categoria \n");
        String nombre = sc.nextLine();
        //validamos el nombre de la categoria, que no sea null ni este ya utilizado
        Validaciones.validarSiExisteCategoria(nombre);
        System.out.println("Ingrese una descripcion para la categoria " + nombre);
        String descripcion = sc.nextLine();
        Categoria categoria1 = new Categoria(nombre,descripcion);
        categorias.add(categoria1);
        System.out.println("categoria creada con exito");
    }
    
    public static void listarCategorias(){
        System.out.println("Categorias: ");
        for (Categoria c: categorias){
            if(!c.isEliminado()){
                System.out.println(c);
            }
        }
        
    }
    
    
    public static void editarCategoria(){
        listarCategorias();
        System.out.println("Ingrese el Id de la categoria que desea editar: ");
        Long id = Long.parseLong(sc.nextLine());
        
        Categoria categAEditar = Validaciones.buscarCategoriaPorId(id);
        
            
        System.out.println("Ingrese el nuevo nombre de la categoria");
        String nombre = sc.nextLine();
        
        //en caso de mantener el mismo nombre evitamos la validacion
        if (!nombre.equals(categAEditar.getNombre())) {
            Validaciones.validarSiExisteCategoria(nombre);
            }
        
        System.out.println("Ingrese la nueva descripcion para su categoria " + nombre +": ");
        String descripcion = sc.nextLine();
        categAEditar.setNombre(nombre);
        categAEditar.setDescripcion(descripcion);
            
        System.out.println(" Categoria editada con exito");
            
            
            
        
           
        
        
        
    }
    
    
    public static void eliminarCategoria(){
        listarCategorias();
        System.out.println("Ingrese el Id de la categoria que desea eliminar: ");
        Long id = Long.parseLong(sc.nextLine());
        
        Categoria catAEliminar = Validaciones.buscarCategoriaPorId(id);
        
        
        catAEliminar.setEliminado(true);
        System.out.println("Categoria "+ catAEliminar.getNombre() + " "+ "eliminada con exito");
        
       
        
        
    }
    
    
    
    
    
    
    //METODOS PARA PRODUCTO
    
    
    
    
    
    
    public static void crearProducto(){
        System.out.println("Ingrese el nombre que desea para el nuevo producto \n");
        String nombre = sc.nextLine();
        //validamos el nombre del producto, que no sea null ni este ya utilizado
        Validaciones.validarProducto(nombre);
        System.out.println("Ingrese el precio del producto " + nombre);
        double precio = Double.parseDouble(sc.nextLine());
        //validamos el precio
        Validaciones.validarNumero(precio);
        
        System.out.println("Ingrese la descripcion para el producto");
        String descripcion = sc.nextLine();
        
        System.out.println("Ingrese el stock del producto");
        int stock = Integer.parseInt(sc.nextLine());
        //validamos el stock
        Validaciones.validarNumero(stock);
        
        
        System.out.println("Ingrese una imagen del producto");
        String imagen = sc.nextLine();
        
        //asignamos un boolean a disponible
        boolean disponible = stock <0;
       
        
        System.out.println("Ingrese la categoria a la que pertenece el producto");
        String nombreCategoria =  sc.nextLine();
        //validamos que esa categoria exista
        Validaciones.validarSiNoExisteCategoria(nombreCategoria);
        
        Categoria catProd = Validaciones.obtenerCategoriaPorNombre(nombreCategoria);
        
       
        
        
        Producto productoNuevo = new Producto(nombre,precio,descripcion,stock,imagen,disponible,catProd);
        productos.add(productoNuevo);
        System.out.println("Producto creado con exito");
    }
    
    public static void listarProductos(){
        System.out.println("Productos: ");
        for (Producto p: productos){
            if(!p.isEliminado()){
                System.out.println(p);
            }
        }
        
    }
    
    
    public static void editarProducto(){
        listarProductos();
        System.out.println("Ingrese el Id del producto que desea editar: ");
        Long id = Long.parseLong(sc.nextLine());
        
        Producto prodAEditar = Validaciones.buscarProductoPorId(id);
        
            
        System.out.println("Ingrese el nombre nuevo del producto");
        String nombre = sc.nextLine();
        if (!nombre.equals(prodAEditar.getNombre())){
           Validaciones.validarProducto(nombre);
           }
            
        prodAEditar.setNombre(nombre);
            
        System.out.println("Ingrese el precio nuevo del producto");
        double precio = Double.parseDouble(sc.nextLine());
        Validaciones.validarNumero(precio);
        prodAEditar.setPrecio(precio);
            
        System.out.println("Ingrese la nueva descripcion para su categoria " + nombre +": ");
        String descripcion = sc.nextLine();
        prodAEditar.setDescripcion(descripcion);
            
        System.out.println("Ingrese el stock nuevo del producto");
        int stock = Integer.parseInt(sc.nextLine());
        Validaciones.validarNumero(stock);
        prodAEditar.setStock(stock);
            
        System.out.println("Ingrese la nueva imagen del producto");
        String imagen = sc.nextLine();
        prodAEditar.setImagen(imagen);
            
        //si el stock es mayor a cero se le asignara true a disponible
        boolean disponible = stock >0;
        prodAEditar.setDisponible(disponible);
            
        System.out.println("Ingrese el nombre de la nueva Categoria del producto");
        listarCategorias();
        String nombreCat = sc.nextLine();
        Validaciones.validarSiNoExisteCategoria(nombreCat);
        Categoria catNueva = Validaciones.obtenerCategoriaPorNombre(nombreCat);
            
        prodAEditar.setCategoria(catNueva);
            
        System.out.println(" Producto editado con exito");
            
            
            
        
        
        
    }
    
    
    
    
    public static void eliminarProducto(){
        listarProductos();
        System.out.println("Ingrese el Id del producto que desea eliminar: ");
        Long id = Long.parseLong(sc.nextLine());
        
        Producto prodAEliminar = Validaciones.buscarProductoPorId(id);
        
        
        prodAEliminar.setEliminado(true);
        System.out.println("Producto "+ prodAEliminar.getNombre() + " "+ "eliminado con exito");
        
        
        
        
    }
    
    
    
    
    
    
    //METODOS PARA USUARIO
    
    
    
    
    
    
    
    
    public static void crearUsuario(){
        System.out.println("Ingrese el nombre que desea para el nuevo usuario \n");
        String nombre = sc.nextLine();
        System.out.println("Ingrese el apellido");
        String apellido = sc.nextLine();
        //validamos el nombre y apellido
        Validaciones.validarUsuario(nombre,apellido);
        
        System.out.println("Ingrese el mail del usuario");
        String mail = sc.nextLine();
        Validaciones.validarMailUsuario(mail);
        
        System.out.println("Ingrese el numero de celular");
        String celular = sc.nextLine();
        
        System.out.println("Ingrese la contraseña para su usuario");
        String contrasenia = sc.nextLine();
        Validaciones.validarCadena(contrasenia);
        
        System.out.println("Ingrese el nombre rol: USUARIO/ADMIN");
        String rolString = sc.nextLine();
        Validaciones.validarRolUsuario(rolString);
        //una vez verificado lo convertimos a tipo Rol
        Rol rol = Rol.valueOf(rolString.toUpperCase());
        
        
        Usuario usuarioNuevo = new Usuario(nombre,apellido,mail,celular,contrasenia,rol);
        usuarios.add(usuarioNuevo);
        System.out.println("Usuario creado con exito");
    }
    
    
    public static void listarUsuarios(){
        System.out.println("Usuarios: ");
        for (Usuario u: usuarios){
            if(!u.isEliminado()){
                System.out.println("usuario #"+u.getId()+": "+u.getNombre()+" "+u.getApellido()+ 
                        "email: "+ u.getMail() + " rol:" + u.getRol());
            }
        }
        
    }
    
    
    
     public static void editarUsuario(){
        listarUsuarios();
        System.out.println("Ingrese el Id del usuario que desea editar: ");
        Long id = Long.parseLong(sc.nextLine());
        
        Usuario usuarioAEditar = Validaciones.buscarUsuarioPorId(id);
        
            
            
        System.out.println("Ingrese el mail del usuario ");
        String mail = sc.nextLine();
        Validaciones.validarMailUsuario(mail);
        usuarioAEditar.setMail(mail);
            
        System.out.println("Ingrese el celular del usuario");
        String celular = sc.nextLine();
        usuarioAEditar.setCelular(celular);
            
            
        System.out.println("Ingrese la nueva contrasenia");
        String contrasenia = sc.nextLine();
        Validaciones.validarCadena(contrasenia);
        usuarioAEditar.setContrasenia(contrasenia);
            
        System.out.println("Ingrese el rol: USUARIO/ADMIN");
        String rolString = sc.nextLine();
        Validaciones.validarRolUsuario(rolString);
        Rol rol = Rol.valueOf(rolString.toUpperCase());
        usuarioAEditar.setRol(rol);
            
            
        System.out.println("Datos de usuario actualizados con exito");
            
            
            
        
        
        
    }
     
     
     
    
    
    
    public static void eliminarUsuario(){
        System.out.println("Ingrese el Id del usuario que desea eliminar: ");
        Long id = Long.parseLong(sc.nextLine());
        
        Usuario userAEliminar = Validaciones.buscarUsuarioPorId(id);
        
        
        userAEliminar.setEliminado(true);
        System.out.println("Usuario id #"+userAEliminar.getId()+ ": "+ userAEliminar.getNombre() + " "+ "eliminado con exito");
        
        
        
        
    }
    
    
    
    
    //METODOS PARA PEDIDOS
    
    
    
    public static void crearPedido(){
        
        LocalDate fecha = LocalDate.now();
        System.out.println("Ingrese el estado del pedido: PENDIENTE/CONFIRMADO/CANCELADO/TERMINADO \n");
        String estadoString = sc.nextLine();
        Validaciones.validarEstadoPedido(estadoString);
        Estado estadoPedido = Estado.valueOf(estadoString.toUpperCase());
        //como aun no  existen detalles de pedidos inicializamos total en 0
        Double total = 0.0;
        
        System.out.println("Ingrese la forma de Pago: TARJETA/TRANSFERENCIA/EFECTIVO");
        String fPagoString = sc.nextLine();
        Validaciones.validarFormaPagoPedido(fPagoString);
        FormaPago formaPago = FormaPago.valueOf(fPagoString.toUpperCase());
        
        listarUsuarios();
        System.out.println("Ingrese el numero de id del usuario ");
        Long id = Long.parseLong(sc.nextLine());
        Usuario usuarioPedido = Validaciones.buscarUsuarioPorId(id);
        
        Pedido nuevoPedido = new Pedido(fecha,estadoPedido,total,formaPago,usuarioPedido);
        pedidos.add(nuevoPedido);
        
        System.out.println("Pedido creado con exito");
       
    }
    
    public static void listarPedidos(){
        System.out.println("Pedidos: ");
        for (Pedido ped: pedidos){
            if(!ped.isEliminado()){
                System.out.println("Pedido #"+ped.getId()+": realizado en fecha: "+ped.getFecha()+
                        " por el usuario: "+ped.getUsuario().getNombre());
            }
        }
        
    }
    
    
    
    public static void editarPedido(){
        listarPedidos();
        System.out.println("Ingrese el Id del pedido que desea editar: ");
        Long id = Long.parseLong(sc.nextLine());
        
        Pedido pedAEditar = Validaciones.buscarPedidoPorId(id);
        
            
        System.out.println("Ingrese el nuevo estado de pedido: PENDIENTE/CONFIRMADO/CANCELADO/TERMINADO \n");
        String estadoString = sc.nextLine();
        Validaciones.validarEstadoPedido(estadoString);
        Estado estadoPedido = Estado.valueOf(estadoString.toUpperCase());
            
        pedAEditar.setEstado(estadoPedido);
        
        System.out.println("Ingrese la nueva forma de pago del pedido: TARJETA/TRANSFERENCIA/EFECTIVO");
        String fPagoString = sc.nextLine();
        Validaciones.validarFormaPagoPedido(fPagoString);
        FormaPago formaPago = FormaPago.valueOf(fPagoString.toUpperCase());
        
        pedAEditar.setFormapago(formaPago);
        
            
        System.out.println(" Pedido actualizado con exito");
            
            
            
    }
        
    
     public static void eliminarPedido(){
         listarPedidos();
        System.out.println("Ingrese el Id del pedido que desea eliminar: ");
        Long id = Long.parseLong(sc.nextLine());
        
        Pedido pedAEliminar = Validaciones.buscarPedidoPorId(id);
        
        
        pedAEliminar.setEliminado(true);
        System.out.println("Pedido #"+ pedAEliminar.getId() + " realizado en fecha: "+ pedAEliminar.getFecha()+ " eliminado con exito");
        
        
        
    }

    
        
    
    
    
    
    
    
    
}
