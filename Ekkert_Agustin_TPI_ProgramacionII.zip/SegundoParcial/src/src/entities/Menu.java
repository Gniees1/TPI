
package src.entities;

import java.util.Scanner;


public class Menu {
    Scanner sc = new Scanner(System.in);
    String cadenaSubMenu = " 1.Listar \n 2.Crear \n 3.Editar \n 4.Eliminar \n Seleccione: ";
        
    
    public  void mostrarMenu(){
        
        
        
        String cadenaMenu= "=== SISTEMA DE PEDIDOS (FOOD STORE) === \n 1. Categorias \n 2. Productos \n 3.Usuarios \n 4.Pedidos \n 0.Salir \n Seleccione: ";
        
        
        boolean bandera = false;
        
        while(bandera == false){
            System.out.println(cadenaMenu);
            System.out.println("Seleccione una opcion");
            int opcion = Integer.parseInt(sc.nextLine());
            
            
            switch (opcion){
                case 1 -> MenuCategorias();
                case 2 -> MenuProductos();
                case 3 -> MenuUsuarios();
                case 4 -> MenuPedidos();
                case 0 -> {
                    System.out.println("Hasta pronto!");
                    bandera = true;
                    }
                default -> System.out.println("Ingrese una opcion valida");
            }
            
            
        }
        
    
        
        
    }
    
    //creamos un submenu para cada entidad de la lista
   public void MenuCategorias(){
        System.out.println(cadenaSubMenu);
        System.out.println("Seleccione una opcion");
        int opcionCat = Integer.parseInt(sc.nextLine());
        
        //acedemos al submenu
        switch(opcionCat){
            case 1 -> DataBase.listarCategorias();
            case 2 -> DataBase.crearCategoria();
            case 3 -> DataBase.editarCategoria();
            case 4 -> DataBase.eliminarCategoria();
        }
        
    } 
    
   
   public void MenuProductos(){
        System.out.println(cadenaSubMenu);
        System.out.println("Seleccione una opcion");
        int opcionProd = Integer.parseInt(sc.nextLine());
        
        //acedemos al submenu
        switch(opcionProd){
            case 1 -> DataBase.listarProductos();
            case 2 -> DataBase.crearProducto();
            case 3 -> DataBase.editarProducto();
            case 4 -> DataBase.eliminarProducto();
        }
        
    } 
   
   public void MenuUsuarios(){
        System.out.println(cadenaSubMenu);
        System.out.println("Seleccione una opcion");
        int opcionUser = Integer.parseInt(sc.nextLine());
        
        //acedemos al submenu
        switch(opcionUser){
            case 1 -> DataBase.listarUsuarios();
            case 2 -> DataBase.crearUsuario();
            case 3 -> DataBase.editarUsuario();
            case 4 -> DataBase.eliminarUsuario();
        }
        
    } 
   
   public void MenuPedidos(){
        System.out.println(cadenaSubMenu);
        System.out.println("Seleccione una opcion");
        int opcionPed = Integer.parseInt(sc.nextLine());
        
        //acedemos al submenu
        switch(opcionPed){
            case 1 -> DataBase.listarPedidos();
            case 2 -> DataBase.crearPedido();
            case 3 -> DataBase.editarPedido();
            case 4 -> DataBase.eliminarPedido();
        }
        
    } 
   
    
    
    
    
    @Override
    public String toString() {
        return "Menu{" + '}';
    }

   
    
    
    
    
}
