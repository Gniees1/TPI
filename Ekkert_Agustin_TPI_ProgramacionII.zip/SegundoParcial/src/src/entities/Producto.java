
package src.entities;



public class Producto extends Base{

    //Atributos
    
    private String nombre;
    private Double precio;
    private String descripcion;
    private int stock;
    private String imagen;
    private boolean disponible;
    private Categoria categoria;
    private static Long ultimoId = 0L;
    
    
    //Constructor
    
    public Producto( String nombre,Double precio, String descripcion, int stock, String imagen, boolean disponible, Categoria categoria){
        
        super();
        super.setId(++ultimoId);
        this.nombre = nombre;
        this.precio = precio;
        this.descripcion = descripcion;
        this.stock = stock;
        this.imagen = imagen;
        this.disponible = disponible;
        this.categoria = categoria;
        
    }
    
    
    //Getters

    public String getNombre() {
        return nombre;
    }

    public Double getPrecio() {
        return precio;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public int getStock() {
        return stock;
    }

    public String getImagen() {
        return imagen;
    }

    public boolean isDisponible() {
        return disponible;
    }

    public Categoria getCategoria() {
        return categoria;
    }
    
    //Setters

    public void setPrecio(Double precio) {
        this.precio = precio;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    public void setDisponible(boolean disponible) {
        this.disponible = disponible;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public void setImagen(String imagen) {
        this.imagen = imagen;
    }

    public void setCategoria(Categoria categoria) {
        this.categoria = categoria;
    }

 
    
    
    
    
    @Override
    public String toString() {
        return "Producto#" + this.getId() + ": "+ this.getNombre() + " precio: "+ this.getPrecio() +
                " Stock: "+ this.stock;
    }
    
    
}
