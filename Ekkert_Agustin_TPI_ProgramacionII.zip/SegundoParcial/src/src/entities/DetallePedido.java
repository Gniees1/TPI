
package src.entities;



public class DetallePedido extends Base{

    //Atributos
    
    private int cantidad;
    private Double subtotal;
    private Producto producto;
    private static Long ultimoId = 0L;
    
    
    //Constructor
    
    public DetallePedido( int cantidad, Producto producto ){
        super();
        super.setId(++ultimoId);
        this.cantidad = cantidad;
        this.producto = producto;
        
        this.subtotal = cantidad * producto.getPrecio();
    }
    
    //Getters

    public int getCantidad() {
        return cantidad;
    }

    public Double getSubtotal() {
        return subtotal;
    }

    public Producto getProducto() {
        return producto;
    }
    
    
    //Setters

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
        subtotal = calcularSubtotal();
    }
    
    
    public Double calcularSubtotal(){
        return cantidad * producto.getPrecio();
    }

    
    
    
    
    @Override
    public String toString() {
        return "- DetallePedido #"+getId()+": "+ producto.getNombre()+ " x "+cantidad+" =>Subtotal: $"+ calcularSubtotal();
    }
    
}
