
package src.entities;

import Excepciones.InvalidNameException;
import Excepciones.ValorInexistenteException;
import Excepciones.ValorDuplicadoException;
import Excepciones.ValorNegativoException;
import static src.entities.DataBase.categorias;
import static src.entities.DataBase.pedidos;
import static src.entities.DataBase.productos;
import static src.entities.DataBase.usuarios;


public class Validaciones {
    
    
    //Validacion generales
    public static void validarCadena(String cadena){
        if (cadena == null || cadena.trim().isEmpty()){
            throw new InvalidNameException("la cadena no debe ser null ni estar vacia");
        }
    }
    
    public static void validarNumero(double n){
        if (n < 0){
            throw new ValorNegativoException("El valor no puede ser negativo");
        }
    }
    
    
    
    //Validaciones para Categoria
    
    
    //creamos un metodo para buscar una categoria por su id
    
    public static Categoria buscarCategoriaPorId(Long id){
        int i = 0;
        Categoria categoriaEncontrada = null;
        
        while (i < categorias.size() && categoriaEncontrada == null) {
        if (categorias.get(i).getId().equals(id)) {
            return categorias.get(i);
        }
        i++;
    }
        throw new ValorInexistenteException("Esta categoria no existe");
    }
    
    
    public static Categoria obtenerCategoriaPorNombre(String nombre) {

    for (Categoria c : DataBase.categorias) {
        if (c.getNombre().equalsIgnoreCase(nombre)) {
            return c;
        }
    }

    return null;
}
    
    
    public static void validarSiExisteCategoria(String nombre){
        validarCadena(nombre);
        if(obtenerCategoriaPorNombre(nombre) != null){
            throw new ValorDuplicadoException("esta categoria ya existe");
        }
        
    }
    
    public static void validarSiNoExisteCategoria (String nombre){
        validarCadena(nombre);
        if(obtenerCategoriaPorNombre(nombre) == null){
            throw new InvalidNameException("esta categoria mp existe");
        }
    }
    
    
    
    
    
    //Validaciones para Producto
    
    public static Producto buscarProductoPorId(Long id){
        int i = 0;
        Producto productoEncontrado = null;
        
        while (i < productos.size() && productoEncontrado == null) {
        if (productos.get(i).getId().equals(id)) {
             return productos.get(i);
        }
        i++;
    }
       throw new ValorInexistenteException("Este Producto no existe");
    }
    
    
    
    public static void validarProducto(String nombre){
        validarCadena(nombre);
        for (Producto p: DataBase.productos){
            if(p.getNombre().equalsIgnoreCase(nombre)){
                throw new ValorDuplicadoException("este producto ya existe");
            }
        }
        
    }
    
    
    
    
    //Validaciones para Usuario
    
    
     public static Usuario buscarUsuarioPorId(Long id){
        int i = 0;
        Usuario usuarioEncontrado = null;
        
        while (i < usuarios.size() && usuarioEncontrado == null) {
        if (usuarios.get(i).getId().equals(id)) {
            return usuarios.get(i);
        }
        i++;
    }
        throw new ValorInexistenteException("Este usuario no existe");
    }
    
    
    public static void validarUsuario(String nombre, String apellido){
        //para que puedan existir usuarios con mismo nombre, nos aseguramos consultando tambien por apellido
        validarCadena(nombre);
        validarCadena(apellido);
        for (Usuario u: DataBase.usuarios){
            if(u.getNombre().equalsIgnoreCase(nombre) && u.getApellido().equalsIgnoreCase(apellido)){
                throw new ValorDuplicadoException("este usuario ya existe");
            }
        }
        
    }
    
    public static void validarMailUsuario(String mail){
        validarCadena(mail);
        
        for (Usuario u: DataBase.usuarios){
            if(u.getMail().equalsIgnoreCase(mail)){
                throw new ValorDuplicadoException("este email ya esta en uso");
            }
        }
        
    }
    
    
    public static void validarRolUsuario(String rol){
        validarCadena(rol);
        
        if (!rol.equalsIgnoreCase("USUARIO") && !rol.equalsIgnoreCase("ADMIN")) {
        throw new IllegalArgumentException("Rol inválido");
    }
        
        
    }
    
    
    
    
    //METODOS PEDIDO
    
    
    
    public static Pedido buscarPedidoPorId(Long id){
        int i = 0;
        Pedido pedidoEncontrado = null;
        
        while (i < pedidos.size() && pedidoEncontrado == null) {
        if (pedidos.get(i).getId().equals(id)) {
            return pedidos.get(i);
        }
        i++;
    }
        throw new ValorInexistenteException("Este Pedido no existe");
    }
    
    
    
    public static void validarEstadoPedido(String estado){
        validarCadena(estado);
        
        if (!estado.equalsIgnoreCase("PENDIENTE") && !estado.equalsIgnoreCase("CONFIRMADO") && !estado.equalsIgnoreCase("TERMINADO") && !estado.equalsIgnoreCase("CANCELADO")) {
        throw new IllegalArgumentException("Estado inválido");
    }
        
        
    }
    
    public static void validarFormaPagoPedido(String fp){
        validarCadena(fp);
        
        if (!fp.equalsIgnoreCase("TARJETA") && !fp.equalsIgnoreCase("EFECTIVO") && !fp.equalsIgnoreCase("TRANSFERENCIA") ) {
        throw new IllegalArgumentException("Forma de pago inválida");
    }
        
        
    }
    
    
    
    
    
    
    
}
