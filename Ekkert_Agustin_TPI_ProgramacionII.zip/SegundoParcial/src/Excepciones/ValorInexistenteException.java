/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Excepciones;

/**
 *
 * @author Agu
 */
public class ValorInexistenteException extends RuntimeException {
    
    public ValorInexistenteException(String message) {
        super(message);
    }
    
    
}
