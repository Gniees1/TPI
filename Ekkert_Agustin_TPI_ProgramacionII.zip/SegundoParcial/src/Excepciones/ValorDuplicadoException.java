
package Excepciones;


public class ValorDuplicadoException extends RuntimeException {
    
    public ValorDuplicadoException(String message) {
        super(message);
    }
    
}
